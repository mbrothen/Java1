
public class SandwichFilling {
	private String fillingType;
	private double calPerServing;
	/*
	public void setFilling(String filling)
	{
		this.fillingType = filling;
	}
	public void setCalPerServing(double cals)
	{
		this.calPerServing = cals;
	}
	public String getFillingType()
	{
		return fillingType;
	}
	public double getCalPerServing()
	{
		return calPerServing;
	}*/
	public SandwichFilling() {
		this.fillingType = "";
		this.calPerServing = 0;
	}
	public SandwichFilling(String fill) {
		this.fillingType = fill;
	}
	public SandwichFilling(double cals) {
		this.calPerServing = cals;
	}
	public String getFillingType() {
		return fillingType;
	}
	public SandwichFilling(String fill, double cals) {
		this.fillingType = fill;
		this.calPerServing = cals;
	}
	public void setFillingType(String fillingType) {
		this.fillingType = fillingType;
	}
	public double getCalPerServing() {
		return calPerServing;
	}
	public void setCalPerServing(double calPerServing) {
		this.calPerServing = calPerServing;
	}
	
}
