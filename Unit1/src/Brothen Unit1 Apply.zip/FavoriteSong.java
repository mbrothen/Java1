//Filename FovoriteSong.java
//Written by Matt Brothen
//Written on 9/12/18
public class FavoriteSong {
	public static void main(String[] args)
	{
		System.out.println("Who let the dogs out");
		System.out.println("Woof, woof, woof, woof, woof");
		System.out.println("Who let the dogs out");
		System.out.println("Woof, woof, woof, woof, woof");

	}
	
}
