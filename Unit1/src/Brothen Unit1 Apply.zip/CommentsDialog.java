//Filename CommentsDialog.java
//Written by Matt Brothen
//Written on 9/12/18import javax.swing.JOptionPane;
import javax.swing.JOptionPane;
public class CommentsDialog {
	public static void main(String[] args)
	{
		JOptionPane.showMessageDialog(null,  "Program comments are nonexecuting statements you add to a file for the purpose of documentation.");
	}
	//Program comments are nonexecuting statements you add to a file for the purpose of documentation.
	/*Program comments are nonexecuting statements you add to a file for the purpose of documentation.*/
	/** 
	 * Program comments are nonexecuting statements you add to a file for the purpose of documentation.
	 * @author mbrothen
	 *
	 */
	
}
