//Filename Comments.java
//Written by Matt Brothen
//Written on 9/12/18
public class Comments {
	public static void main(String[] args)
	{
		System.out.println("Program comments are nonexecuting statements you add to a file for the purpose of documentation.");
	}
	//Program comments are nonexecuting statements you add to a file for the purpose of documentation.
	/*Program comments are nonexecuting statements you add to a file for the purpose of documentation.*/
	/** 
	 * Program comments are nonexecuting statements you add to a file for the purpose of documentation.
	 * @author mbrothen
	 *
	 */
	
}
