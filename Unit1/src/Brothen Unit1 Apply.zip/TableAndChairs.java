//Filename TableAndchairs.java
//Written by Matt Brothen
//Written on 9/12/18
public class TableAndChairs {
	public static void main(String[] args)
	{
		System.out.println("X                     X");
		System.out.println("X                     X");
		System.out.println("X     XXXXXXXXXX      X");
		System.out.println("XXXX  X        X  XXXXX");
		System.out.println("X  X  X        X  X   X");
		System.out.println("X  X  X        X  X   X");
	}
	
}
