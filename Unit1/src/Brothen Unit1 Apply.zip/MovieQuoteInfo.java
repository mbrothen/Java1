//Filename MovieQuote.java
//Written by Matt Brothen
//Written on 9/12/18
public class MovieQuoteInfo {
	public static void main(String[] args)
	{
		System.out.println("Just when I thought you couldn't possibly be any \ndumber, you go and do something like this... \nand totally redeem yourself!");
		System.out.println("Dumb and Dumber");
		System.out.println("Harry Dunne");
		System.out.println("1994");
	}
	
}
