//Filename HelloDialog.java
//Written by Matt Brothen
//Written on 9/12/18
import javax.swing.JOptionPane;
public class HelloDialog {
	public static void main(String[] args)
	{
		JOptionPane.showMessageDialog(null,  "Hello, world!");
		;
	}
	
}
