public class Hello2
/* This class demonstrates the use of the println() 
method to print the message Hello, world!*/


{
	public static void main(String[] args)
	{
		System.out.println("Hello, world!");
	}
}